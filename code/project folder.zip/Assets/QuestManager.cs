﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    void createQuest(int type)
    {
        if(type == 0)
        {
            //wants to create location quest
            
        }

    }
}
