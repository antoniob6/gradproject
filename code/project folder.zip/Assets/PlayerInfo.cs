﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class PlayerInfo : NetworkBehaviour {

    public Canvas canvas;
    public Text scoreField;
    public Text objectiveField;
    public Text healthField;

    [SyncVar]
    public Color spriteColor = Color.white;
    [SyncVar]
    public string Cname = "default";
    [SyncVar]
    public float scoref = 0f;
    [SyncVar]
    public string objectiveText = "objectiveText";
    [SyncVar]
    public bool hasDied = false;




    void Start() {



    }
    void LateUpdate() {
        scoreField.text = "score: " + scoref.ToString();
        objectiveField.text = objectiveText;
    }
    [ClientRpc]
    public void RpcUpdateScore(float scorefn) {
        scoref = scorefn;

    }
    [ClientRpc]
    public void RpcUpdateText(string text) {
        objectiveText = text;

    }
    [ClientRpc]
    public void RpchasDied(bool text) {
        hasDied = text;

    }



    public void updateHealth(int hp) {
        healthField.text = hp.ToString();

    }
}
