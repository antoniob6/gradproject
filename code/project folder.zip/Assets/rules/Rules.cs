﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rules :MonoBehaviour {
    public float jumpHeight = 2f;
    public float playerSpeed = 2f;
    public float falldamage = 10f;


    public int mapSeed = 0;
    public float gravity = 10f;
    public bool isPlanetaryGravity = false;
    public float mapwidth = 100f;
    public float mapHeight = 20f;




	
}
