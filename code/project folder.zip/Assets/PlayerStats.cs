﻿using System.Collections;
using System.Collections.Generic;
//this script collects the player's stats throughout the game
using UnityEngine;

public class PlayerStats : MonoBehaviour {

	// Use this for initialization
	void Start () {
     
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
