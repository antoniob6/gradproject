﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace Prototype.NetworkLobby
{
    public class LobbyCountdownPanel : MonoBehaviour
    {
        public Text UIText;
    }
}