﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmartEnemy : MonoBehaviour {
    public GameManager GM;
    
	// Use this for initialization
	void Start () {
        GM = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
        if (!GM) {
            Debug.Log("Couldn't find GameManager on smart enemy");
        }
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
